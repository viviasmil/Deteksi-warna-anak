import cv2
import numpy as np

def nothing(x):
    pass

cv2.namedWindow("HSV Tracker")
cv2.createTrackbar("LH", "HSV Tracker", 0, 179, nothing)
cv2.createTrackbar("LS", "HSV Tracker", 0, 255, nothing)
cv2.createTrackbar("LV", "HSV Tracker", 0, 255, nothing)
cv2.createTrackbar("UH", "HSV Tracker", 179, 179, nothing)
cv2.createTrackbar("US", "HSV Tracker", 255, 255, nothing)
cv2.createTrackbar("UV", "HSV Tracker", 255, 255, nothing)

cap = cv2.VideoCapture(0)

while True:
    _, frame = cap.read()
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    lh = cv2.getTrackbarPos("LH", "HSV Tracker")
    ls = cv2.getTrackbarPos("LS", "HSV Tracker")
    lv = cv2.getTrackbarPos("LV", "HSV Tracker")
    uh = cv2.getTrackbarPos("UH", "HSV Tracker")
    us = cv2.getTrackbarPos("US", "HSV Tracker")
    uv = cv2.getTrackbarPos("UV", "HSV Tracker")

    lower_bound = np.array([lh, ls, lv])
    upper_bound = np.array([uh, us, uv])

    mask = cv2.inRange(hsv, lower_bound, upper_bound)
    result = cv2.bitwise_and(frame, frame, mask=mask)

    cv2.imshow("Mask", mask)
    cv2.imshow("Result", result)
    cv2.imshow("Original", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        print(f"HSV Range = Lower: {lower_bound}, Upper: {upper_bound}")
        break

cap.release()
cv2.destroyAllWindows()
