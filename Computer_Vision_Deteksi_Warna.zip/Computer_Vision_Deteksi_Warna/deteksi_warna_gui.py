import cv2
import numpy as np

def draw_and_count(mask, frame, color_name, box_color, min_area=5000, max_boxes=1):
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)

    count = 0
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area > min_area:
            x, y, w, h = cv2.boundingRect(cnt)
            cv2.rectangle(frame, (x, y), (x + w, y + h), box_color, 2)
            cv2.putText(frame, color_name, (x + 5, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, box_color, 2)
            count += 1
            if count >= max_boxes:
                break
    return count

cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)
    frame_height, frame_width = frame.shape[:2]
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    color_data = {
        'Merah':  ([0, 100, 100], [10, 255, 255], (0, 0, 255)),
        'Kuning': ([22, 93, 100], [32, 255, 255], (0, 255, 255)),
        'Hijau':  ([36, 50, 70], [89, 255, 255], (0, 255, 0)),
        'Biru':   ([90, 50, 70], [128, 255, 255], (255, 0, 0)),
        'Ungu':   ([129, 50, 70], [158, 255, 255], (255, 0, 255)),
        'Coklat': ([10, 100, 20], [20, 255, 180], (42, 42, 165)),
        'Cream':  ([20, 40, 200], [40, 100, 255], (240, 230, 140)),
        'Oranye': ([10, 100, 100], [20, 255, 255], (0, 165, 255)),
        'Hitam':  ([0, 0, 0], [180, 255, 50], (50, 50, 50)),
        'Putih':  ([0, 0, 200], [180, 30, 255], (255, 255, 255)),
        'Abu-abu':([0, 0, 60], [180, 30, 180], (160, 160, 160)),
        'Pink':   ([160, 70, 100], [179, 255, 255], (255, 105, 180)),
    }

    detected_info = []

    for name, (lower, upper, color) in color_data.items():
        mask = cv2.inRange(hsv, np.array(lower), np.array(upper))
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        count = draw_and_count(mask, frame, name, color)
        if count > 0:
            detected_info.append((name, count, color))

    # === INTERFACE TAMPILAN ===
    # Judul utama di tengah atas
    title = "== Tebak Warna =="
    (title_width, _), _ = cv2.getTextSize(title, cv2.FONT_HERSHEY_DUPLEX, 1.2, 2)
    title_x = (frame_width - title_width) // 2
    cv2.rectangle(frame, (0, 0), (frame_width, 55), (40, 40, 40), -1)
    cv2.putText(frame, title, (title_x, 38), cv2.FONT_HERSHEY_DUPLEX, 1.2, (255, 255, 0), 2)

    # Subjudul Deteksi Warna di tengah
    info_y = 70
    if detected_info:
        nama_warna = detected_info[0][0]
        warna_rgb = detected_info[0][2]
        text = f"Warna yang terdeteksi adalah: {nama_warna}"
        (text_width, _), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)
        text_x = (frame_width - text_width) // 2
        cv2.rectangle(frame, (text_x - 10, info_y), (text_x + text_width + 10, info_y + 40), (0, 0, 0), -1)
        cv2.putText(frame, text, (text_x, info_y + 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, warna_rgb, 2)
    else:
        message = "Ayo arahkan warna ke kamera!"
        (msg_width, _), _ = cv2.getTextSize(message, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)
        msg_x = (frame_width - msg_width) // 2
        cv2.putText(frame, message, (msg_x, info_y + 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

    cv2.imshow('Deteksi Warna Anak', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
