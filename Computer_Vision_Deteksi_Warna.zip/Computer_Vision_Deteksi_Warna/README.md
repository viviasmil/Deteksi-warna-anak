Proyek ini merupakan implementasi sederhana dari sistem Computer Vision untuk mendeteksi objek dengan warna kuning menggunakan Python dan OpenCV. Program ini dapat digunakan untuk berbagai aplikasi seperti pemrosesan citra, pelacakan objek, dan sistem otomatisasi berbasis warna.

Tujuan Proyek
1.Mendeteksi objek berwarna kuning pada gambar atau video secara real-time.

2.Menampilkan hasil deteksi dengan bounding box pada objek kuning.

3.Menggunakan teknik segmentasi warna di ruang warna HSV.
