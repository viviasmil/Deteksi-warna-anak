import cv2
import numpy as np

def draw_and_count(mask, frame, color_name, box_color, min_area=6000, max_boxes=1):
    contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)

    count = 0
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area > min_area:
            x, y, w, h = cv2.boundingRect(cnt)
            cv2.rectangle(frame, (x, y), (x + w, y + h), box_color, 2)
            count += 1
            if count >= max_boxes:
                break
    return count

cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    color_data = {
        'Merah':  ([0, 120, 70], [10, 255, 255], (0, 0, 255)),
        'Kuning': ([20, 100, 100], [30, 255, 255], (0, 255, 255)),
        'Hijau':  ([40, 70, 70], [70, 255, 255], (0, 255, 0)),
        'Biru':   ([100, 150, 0], [140, 255, 255], (255, 0, 0)),
        'Ungu':   ([130, 50, 50], [160, 255, 255], (255, 0, 255)),
        'Coklat': ([10, 100, 20], [20, 255, 200], (42, 42, 165)),
        'Cream':  ([20, 30, 200], [40, 100, 255], (240, 230, 140)),
        'Oranye': ([10, 100, 100], [20, 255, 255], (0, 165, 255)),
        'Hitam':  ([0, 0, 0], [180, 255, 30], (30, 30, 30)),
        'Putih':  ([0, 0, 200], [180, 40, 255], (255, 255, 255)),
        'Abu-abu':([0, 0, 40], [180, 40, 200], (160, 160, 160)),
        'Pink':   ([160, 50, 100], [170, 255, 255], (255, 105, 180)),
    }

    detected_info = []

    for name, (lower, upper, color) in color_data.items():
        mask = cv2.inRange(hsv, np.array(lower), np.array(upper))
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        count = draw_and_count(mask, frame, name, color)
        if count > 0:
            detected_info.append((name, count, color))

    # Panel info di kiri atas
    y_offset = 30
    cv2.rectangle(frame, (5, 5), (250, y_offset + 25 * len(detected_info)), (0, 0, 0), -1)
    cv2.putText(frame, 'Warna Terdeteksi:', (10, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

    for name, count, color in detected_info:
        y_offset += 25
        text = f'{name} ({count})'
        cv2.putText(frame, text, (10, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

    cv2.imshow('Deteksi Warna Anak', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
