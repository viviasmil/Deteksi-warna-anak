import tkinter as tk
from tkinter import *
import cv2
from PIL import Image, ImageTk
from util import get_limits
import numpy as np

yellow = [0, 255, 255]  # Warna kuning dalam format BGR

def start_camera():
    global cap
    cap = cv2.VideoCapture(0)  # Kamera default
    update_frame()

def update_frame():
    ret, frame = cap.read()
    if ret:
        frame = cv2.flip(frame, 1)  # biar tidak mirror

        hsvImage = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        lowerLimit, upperLimit = get_limits(color=yellow)
        mask = cv2.inRange(hsvImage, lowerLimit, upperLimit)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        for contour in contours:
            if cv2.contourArea(contour) > 1000:
                x, y, w, h = cv2.boundingRect(contour)
                frame = cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 5)

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(rgb)
        imgtk = ImageTk.PhotoImage(image=img)
        lbl.imgtk = imgtk
        lbl.configure(image=imgtk)
    lbl.after(10, update_frame)

root = tk.Tk()
root.title("Deteksi Warna GUI")

btn = Button(root, text="Mulai Kamera", command=start_camera)
btn.pack()

lbl = Label(root)
lbl.pack()

root.mainloop()
